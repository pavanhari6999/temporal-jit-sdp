# Reproduction Guide

## Environment

The verified environment used for the primary experiments included:

- Python 3.13.5
- NumPy 2.3.5
- pandas 2.2.3
- scikit-learn 1.8.0
- SciPy 1.17.0
- XGBoost 3.1.3
- Matplotlib 3.10.8

Install the pinned packages with:

```bash
pip install -r requirements.txt
```

## Execution order

1. Obtain the raw/processed datasets described in `data/README.md`.
2. Open `notebooks/Adaptive_JIT_SDP_Research_Stage8C_BORB_ready.ipynb` in Google Colab or Jupyter.
3. Configure dataset paths.
4. Run preprocessing and dataset-audit cells.
5. Run the chronological frozen-model evaluation.
6. Run temporal segmentation and adaptation experiments.
7. Run sensitivity and uncertainty experiments.
8. Export numerical results.
9. Compare exported results with the CSVs under `results/`.
10. Recompile the manuscript if the source files or figures are changed.

## Primary protocol

Brackets:

- 11,601 total observations
- 8,120 historical observations
- 3,481 future observations
- 6,496 historical development observations
- 1,624 historical validation observations
- 14 original change-level features
- six controlled RFE-selected features: `lt`, `la`, `rexp`, `exp`, `ld`, `nuc`
- Random Forest: 100 trees, maximum depth 5, minimum leaf size 4, `max_features=sqrt`, balanced class weighting, random seed 42
- future evaluation divided into T1–T4

## Adaptation

The evaluated adaptation families are:

- Frozen model
- Cumulative retraining
- Sliding window: 2,000 records
- Sliding window: 4,000 records
- Sliding window: 6,000 records
- Sliding window: 8,000 records
- 4,000-record model with adaptive threshold selection

Cumulative retraining means training a new Random Forest from scratch at each temporal boundary using all labeled observations available at that point. No warm-start or incremental parameter update is used.

Adaptive thresholding uses the latest 1,000 available labeled records for threshold calibration, searches 0.20–0.80 in 0.05 increments using calibration F1, and then fits the final Random Forest using the available 4,000-record window. Future-test labels are never used for threshold selection.

## Statistical analysis

- 2,000 bootstrap resamples for confidence intervals
- Friedman test for multi-project adaptation comparison
- Kendall's W as an effect-size description
- Wilcoxon pairwise comparisons with Holm correction

## Reproducibility boundary

The repository distinguishes executed experiments from literature-only positioning. BORB, ODaSC, PBSA, DeepJIT, CC2Vec, and JITLine are discussed as relevant published baselines, but unmatched published numerical scores are not copied into the result tables. The executed contextual online-baseline comparator is explicitly not claimed to be an exact BORB reproduction.

# Manuscript / Replication Package Status

## Current manuscript

**Version:** V5

**Title:** Temporal Robustness and Lightweight Adaptation for Just-In-Time Software Defect Prediction

**Current artifacts:**
- `manuscript/JIT_SDP_Major_Revision_Draft_v5.pdf`
- `manuscript/JIT_SDP_Major_Revision_Draft_v5.tex`

## Scientific coverage

The revision includes:

- five-project evaluation;
- strict chronological evaluation;
- RFE sensitivity and leakage-control explanation;
- distribution-shift analysis using KS/PSI;
- period-wise temporal performance;
- cumulative and sliding-window adaptation;
- adaptive threshold calibration;
- class-imbalance sensitivity;
- permutation importance;
- XGBoost temporal sensitivity;
- runtime sensitivity;
- bootstrap confidence intervals;
- Friedman test and Kendall's W;
- published-baseline-style contextual comparison;
- explicit baseline-fidelity limitations;
- DeepJIT/CC2Vec/JITLine positioning;
- data/code availability wording;
- publication figures and supplementary figures.

## Public-release action

The remaining external action is to create the public GitHub repository, verify the uploaded contents, optionally create a DOI-bearing Zenodo release, and replace the manuscript's intentionally non-fabricated placeholder wording with the real repository URL/DOI.

# Reviewer Response

The detailed reviewer response is provided in `RESPONSE_TO_REVIEWERS_V4.md`.

The manuscript revision addresses the major requests through:

- five-project evaluation;
- published-baseline-style contextual comparison with explicit fidelity qualification;
- ODaSC/PBSA and DeepJIT/CC2Vec/JITLine positioning;
- empirical rather than algorithmic novelty framing;
- bootstrap confidence intervals;
- Kendall's W and statistical-power limitation;
- RFE feature-count sensitivity and leakage control;
- cumulative and sliding-window adaptation details;
- adaptive-threshold calibration details;
- historical/future and T1–T4 defect rates;
- PSI/KS distribution-shift analysis;
- class-imbalance sensitivity;
- permutation importance;
- XGBoost temporal sensitivity;
- runtime sensitivity;
- replication-package documentation.

# Data Availability Statement

The replication package provides the experimental code, manuscript, figures, numerical result tables, preprocessing documentation, and dataset audit information.

The exact Brackets input used for the primary case study is identified by SHA-256 checksum:

`72d3d69c337a7dd7693363e4c368c459878ef989be6de3a0e37b8aa1081e81fc`

The additional Tomcat, JGroups, Spring-Integration, and Camel streams are processed JIT-SDP/CPJITSDP-style data with delayed-label and commit-type semantics. The repository does not redistribute those raw source files. Users should obtain the corresponding datasets from their original public sources and follow the preprocessing/event-semantics documentation in the notebook.

All reported numerical tables are included under `results/` so that the manuscript values can be audited without treating unmatched external datasets as equivalent inputs.

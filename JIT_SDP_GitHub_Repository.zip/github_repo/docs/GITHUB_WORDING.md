# GitHub / Archival Wording for the Manuscript

## Use immediately after the GitHub repository becomes public

Replace `GITHUB_REPOSITORY_URL` with the actual public repository URL:

> **Code Availability:** The replication package, including the experimental notebook, preprocessing and evaluation procedures, numerical result tables, publication figures, supplementary figures, environment specification, and manuscript source, is publicly available at `GITHUB_REPOSITORY_URL`.

## Use after creating the Zenodo archival release

Replace `GITHUB_REPOSITORY_URL` and `ZENODO_DOI` with the real identifiers:

> **Code Availability:** The complete replication package is publicly available at `GITHUB_REPOSITORY_URL` and is archived at `ZENODO_DOI`. The package contains the experimental notebook, preprocessing and evaluation procedures, numerical result tables, publication figures, supplementary figures, environment specification, and manuscript source.

## Data Availability wording

> **Data Availability:** The repository provides dataset provenance, preprocessing semantics, audit information, and the exact checksum for the Brackets input used in the primary case study. The additional Tomcat, JGroups, Spring-Integration, and Camel streams are processed JIT-SDP/CPJITSDP-style data with delayed-label semantics. Raw input files are not redistributed in this repository; users should obtain the corresponding source datasets from their original public sources and follow the documented preprocessing protocol.

## Repository description for GitHub

> Replication package for “Temporal Robustness and Lightweight Adaptation for Just-In-Time Software Defect Prediction”: chronological JIT-SDP evaluation, distribution-shift analysis, multi-project temporal performance, lightweight adaptation, uncertainty analysis, figures, and manuscript artifacts.

## Suggested GitHub topics

```text
just-in-time-software-defect-prediction
jit-sdp
software-defect-prediction
empirical-software-engineering
temporal-robustness
distribution-shift
random-forest
xgboost
recursive-feature-elimination
online-learning
software-engineering
reproducibility
```

## Important

Do not publish a made-up repository URL or DOI in the manuscript. Create the GitHub repository first, verify that the files are public, then create the archival release, and finally replace the placeholders above with the real identifiers.

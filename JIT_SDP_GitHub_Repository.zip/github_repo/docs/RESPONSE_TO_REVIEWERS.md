# Response to Reviewers — v4

## Overall response
The manuscript was substantially revised around a strict chronological JIT-SDP protocol. The original Brackets analysis was retained as a controlled case study and extended to Tomcat, JGroups, Spring-Integration and Camel. Additional sensitivity, uncertainty, runtime and class-imbalance analyses were executed. Published online and deep-learning baselines are now explicitly separated into executed common-protocol evidence and literature/positioning evidence so that unmatched cross-paper results are not presented as new experiments.

## Major reviewer issues

### 1. Single-project evaluation
**Addressed.** The study now evaluates five projects. Brackets remains the original case study; four additional CPJITSDP-style projects are evaluated under target-project chronological semantics.

### 2. Published online baseline
**Addressed with fidelity qualification.** A corrected published-baseline-style comparator is executed for four projects. The manuscript no longer calls this an exact BORB reproduction. The paper now also explains the published BORB protocol and why exact reproduction requires matching its complete replication configuration.

### 3. ODaSC/PBSA omission
**Addressed through explicit baseline coverage and fidelity disclosure.** ODaSC and PBSA are now identified as established online JIT-SDP baseline families and discussed in Related Work and the baseline-fidelity table. They are not assigned fabricated or unmatched numerical results.

### 4. DeepJIT/CC2Vec/deep baselines
**Addressed through explicit positioning and limitation.** DeepJIT and CC2Vec are discussed, their public artifact ecosystem is acknowledged, and the manuscript explains why their published numerical results are not copied into the present tables. JITLine is also included in positioning.

### 5. Novelty/contribution
**Addressed.** The contribution is explicitly framed as empirical and methodological synthesis: chronology, feature-shift measurement, period-wise degradation, multi-project replication and controlled lightweight adaptation. No new algorithmic novelty is claimed.

### 6. Confidence intervals
**Addressed.** 2,000-bootstrap 95% confidence intervals are reported for frozen/adaptive future-test results.

### 7. Statistical power / Friedman test
**Addressed.** Kendall's W is reported and the limitation of only four temporal units per project is explicitly stated. Statistical interpretation is conservative.

### 8. RFE sensitivity and leakage control
**Addressed.** Feature-count sensitivity is reported, including the fact that five features slightly exceed six on validation F1. Six features are retained because they are the controlled original RFE representation rather than being presented as uniquely optimal.

### 9. Temporal adaptation details
**Addressed.** Cumulative, 2k/4k/6k/8k sliding windows, adaptive thresholding, calibration windows and threshold search are documented. Cumulative retraining is explicitly described as from-scratch retraining on all currently labeled data.

### 10. Defect rates and temporal periods
**Addressed.** Historical/future and T1–T4 defect rates are reported for all five projects.

### 11. Distribution shift / PSI thresholds
**Addressed.** PSI and KS/BH results are reported for Brackets and the manuscript avoids treating distribution shift as proof of conditional concept drift.

### 12. Class imbalance
**Addressed.** Balanced class weighting is compared with SMOTE and ADASYN without using future labels for sampling decisions.

### 13. Feature importance
**Addressed.** Permutation importance is reported for the selected Brackets features.

### 14. XGBoost
**Addressed.** XGBoost is evaluated temporally on Brackets and reported as a learner-family sensitivity rather than mixed into the controlled adaptation comparison.

### 15. Runtime / computational cost
**Addressed.** Runtime per update is measured for the Brackets temporal strategies and reported as hardware/implementation dependent.

### 16. Adaptive threshold attribution
**Addressed.** The manuscript explicitly states that adaptive thresholding is coupled to 4,000-record retraining and therefore cannot be attributed to thresholding alone.

### 17. Broader deployment implications
**Addressed.** The discussion covers false-positive review burden, false negatives, verification latency, calibration, monitoring and human review.

### 18. Reproducibility and data availability
**Addressed structurally.** Exact data checksums, project streams, preprocessing decisions, experiment artifacts and environment information are identified for archival release. The final public URL/DOI is not fabricated.

## Scientific integrity note
The revision intentionally does **not** fabricate exact ODaSC, PBSA, DeepJIT, CC2Vec or BORB-reproduction numbers. Where an exact common-protocol reproduction was not performed, the manuscript says so directly and explains the protocol mismatch. This is preferable to reporting apparently precise but scientifically incomparable values.

# Response to Reviewers — Major Revision v3

## Reviewer 1 — Methods & Theory

**RFE justification:** Added a validation-fold RFE sensitivity table covering 14 through 2 features and a permutation-importance analysis for the selected six features. The manuscript explicitly avoids claiming that six features are uniquely optimal.

**Cumulative retraining:** Clarified that cumulative retraining trains a new Random Forest from scratch at every temporal boundary using all labels available at that point; no warm-start or incremental update is used.

**Statistical power:** Added Kendall's W and explicitly state that four temporal periods limit statistical power.

**Confidence intervals:** Bootstrap confidence intervals are retained for frozen and adaptive configurations.

**Class imbalance:** Added Brackets sensitivity comparisons for balanced class weighting, SMOTE, and ADASYN. Synthetic sampling is fitted only to historical training data.

**ODASC/PBSA / online baselines:** The manuscript now provides a published-baseline-style contextual comparator and clearly states that it is not an exact BORB reproduction. Exact ODASC/PBSA reproduction remains outside the present common-protocol experiment and is identified as future work rather than represented by fabricated numbers.

**Theory:** Added explicit discussion of why smaller windows trade recency against sample size and why window size should be treated as a project-specific operational parameter.

## Reviewer 2 — Experiments & Practical Impact

**Multi-project scope:** Added four additional projects to the original Brackets study.

**Defect rates:** Added historical, full-future, and T1–T4 defect rates.

**Window sensitivity:** Added 2,000/4,000/6,000/8,000-record windows and adaptive thresholding; calibration-window sensitivity now covers 500/1,000/2,000 observations.

**Adaptive threshold:** Explicitly state the calibration criterion, grid, chronology, retraining order, and future-label isolation.

**Runtime:** Added implementation-level runtime measurements and clarified that they are hardware-dependent rather than universal speed claims.

**XGBoost temporal adaptation:** Added a Brackets XGBoost T1–T4 sensitivity experiment while retaining Random Forest as the controlled learner for the main multi-project adaptation analysis.

**Code/data:** The replication package is prepared for archival deposition.

## Reviewer 3 / Meta-review — Clarity & Positioning

**Related work:** Added Jahanshahi et al. (2019), Tabassum et al. (2020), and Pornprasit & Tantithamthavorn (JITLine, 2021), alongside the previously cited Cabral, DeepJIT, Zeng, and Song work.

**Novelty positioning:** The manuscript explicitly states that the contribution is empirical rather than algorithmic and does not claim novelty for chronological evaluation, RFE, Random Forest, XGBoost, sliding windows, or thresholding individually.

**Broader impact:** Added discussion of false positives, false negatives, verification latency, human oversight, and limits of F1 as a proxy for downstream developer productivity.

**Formatting:** The revised PDF was compiled successfully in double-column form with no undefined-reference or citation warnings on the final LaTeX pass.

## Remaining author-side action
Upload the prepared replication package to a public archival repository and replace the placeholder wording with the resulting GitHub/Zenodo URL or DOI. No fabricated URL is included.

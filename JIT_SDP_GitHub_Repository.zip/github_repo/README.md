# Temporal Robustness and Lightweight Adaptation for Just-In-Time Software Defect Prediction

Replication package for the manuscript:

> **Temporal Robustness and Lightweight Adaptation for Just-In-Time Software Defect Prediction**

Authors:
- **D. Pavan Hari Krishna**, M.Tech, Department of CSE, KL University, Vaddeswaram, India
- **Dr. M. V. D. Prasad**, Associate Professor, Department of ECE, KL University, Vaddeswaram, India

## Repository purpose

This repository contains the experimental notebook, manuscript source/PDF, publication figures, supplementary figures, numerical result tables, reviewer-response documentation, and reproducibility notes for the study.

The study evaluates temporal robustness and lightweight within-project adaptation for Just-In-Time Software Defect Prediction (JIT-SDP) using a leakage-resistant chronological protocol.

The original Brackets case study is extended to four additional processed JIT-SDP streams:

- Brackets
- Tomcat
- JGroups
- Spring-Integration
- Camel

The contribution is intentionally **empirical rather than algorithmic**. The work does not claim that Random Forest, RFE, sliding windows, or adaptive thresholding are individually new algorithms.

## Main findings

- The Brackets frozen Random Forest achieves **F1 = 0.5366**, **ROC-AUC = 0.7961**, **PR-AUC = 0.5161**, and **MCC = 0.3900** on the strictly future test set.
- Frozen future-test F1 across the four additional projects ranges from **0.2975 to 0.6741**.
- Temporal performance is project-dependent; three of the four additional projects show lower T1-to-T4 F1, while JGroups is non-monotonic.
- Across 16 project-period observations, the Friedman test gives **p < 0.0001** and **Kendall's W = 0.3271**. This omnibus result does not establish a universally superior adaptation strategy.
- The executed published-baseline-style comparator is explicitly described as a contextual comparator rather than an exact BORB reproduction.
- Bootstrap confidence intervals are provided for frozen and adaptive-threshold configurations.

## Repository structure

```text
.
├── README.md
├── LICENSE
├── CITATION.cff
├── requirements.txt
├── .gitignore
├── manuscript/
│   ├── JIT_SDP_Major_Revision_Draft_v5.pdf
│   └── JIT_SDP_Major_Revision_Draft_v5.tex
├── notebooks/
│   └── Adaptive_JIT_SDP_Research_Stage8C_BORB_ready.ipynb
├── figures/
│   ├── Figure_1_Temporal_F1_All_Projects.png
│   ├── Figure_2_Frozen_vs_Adaptive.png
│   ├── Figure_3_Frozen_F1_Project_Comparison.png
│   ├── Figure_4_Adaptation_Strategy_Comparison.png
│   ├── Figure_5_Defect_Rate_Temporal_Change.png
│   ├── Figure_6_Brackets_PSI_Shift.png
│   ├── Figure_7_RFE_Feature_Count_Sensitivity.png
│   ├── Figure_8_RF_vs_XGBoost_Temporal.png
│   └── updated_figures_source.zip
├── supplementary/
│   ├── Figure_S1_Class_Imbalance_Sensitivity.png
│   └── Figure_S2_Brackets_Class_Distribution.png
├── results/
│   ├── project_frozen_results.csv
│   ├── temporal_f1_results.csv
│   ├── adaptation_strategy_results.csv
│   ├── defect_rates.csv
│   ├── baseline_comparator.csv
│   ├── bootstrap_confidence_intervals.csv
│   ├── rfe_sensitivity.csv
│   ├── class_imbalance_sensitivity.csv
│   ├── xgboost_temporal.csv
│   ├── runtime_sensitivity.csv
│   ├── threshold_calibration_sensitivity.csv
│   └── permutation_importance.csv
├── data/
│   └── README.md
└── docs/
    ├── REPRODUCTION_GUIDE.md
    ├── DATA_AVAILABILITY.md
    ├── REVIEWER_RESPONSE.md
    ├── Adaptive_JIT_SDP_Research_Stage8C_BORB_ready.ipynb
    └── REVIEW_RESPONSE_HISTORY/
```

## Quick start in Google Colab

1. Open `notebooks/Adaptive_JIT_SDP_Research_Stage8C_BORB_ready.ipynb` in Google Colab.
2. Obtain the source datasets described in `data/README.md`.
3. Upload/mount the datasets in Colab.
4. Update the dataset paths in the notebook configuration cell if necessary.
5. Run the notebook from the beginning.
6. The notebook performs chronological preprocessing, model fitting, feature selection, temporal evaluation, adaptation analysis, uncertainty analysis, and result export.

The notebook is the primary executable research artifact. The CSV files in `results/` are the numerical results used for the manuscript and are included to make the reported values directly auditable.

## Important reproducibility rule

**Do not use future-test labels for feature selection, hyperparameter selection, threshold selection, or model fitting.**

The protocol separates historical model development from future evaluation. For the adaptive-threshold configuration, the latest 1,000 currently available labeled observations are used for threshold calibration, candidate thresholds from 0.20 to 0.80 are searched in increments of 0.05, and the final model is fitted on the available 4,000-record window. Future-test labels remain isolated.

## Data availability

The repository does not redistribute every raw dataset file. Dataset provenance, expected filenames/streams, preprocessing semantics, and the Brackets SHA-256 checksum are documented in `data/README.md` and `docs/DATA_AVAILABILITY.md`.

The exact Brackets input used in the study has SHA-256:

```text
72d3d69c337a7dd7693363e4c368c459878ef989be6de3a0e37b8aa1081e81fc
```

The additional CPJITSDP-style streams contain processed online-learning semantics, including delayed label availability and commit-type information. They should not be treated as ordinary independent rows without following the documented event semantics.

## Reproducibility and archival release

The repository is intended to be connected to an archival DOI service such as Zenodo after the GitHub repository is made public. The manuscript deliberately does **not** contain a fabricated GitHub URL or DOI. After the repository is published and archived, insert the real repository URL and DOI into the manuscript's Code Availability statement before journal submission.

## Citation

A machine-readable citation record is provided in `CITATION.cff`.

## License

The research code and accompanying scripts are released under the MIT License. The manuscript remains the intellectual work of the listed authors; journal publication rights should be handled according to the target venue's policy.

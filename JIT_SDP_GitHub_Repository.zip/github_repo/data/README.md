# Data availability and placement

The replication repository intentionally does not redistribute all raw input datasets. Place the required files locally/inside Colab before running the notebook.

## Original Brackets dataset

Expected schema:

```text
author_date_unix_timestamp, fix, ns, nd, nf, entrophy, la, ld, lt,
ndev, age, nuc, exp, rexp, sexp, contains_bug, days_to_first_fix
```

Expected shape: **11,601 rows × 17 columns**.

No missing values or duplicate rows were present in the exact Brackets CSV used in the study.

SHA-256:

```text
72d3d69c337a7dd7693363e4c368c459878ef989be6de3a0e37b8aa1081e81fc
```

## Additional processed projects

The study uses processed CPJITSDP-style streams for:

- Tomcat
- JGroups
- Spring-Integration
- Camel

These streams contain the common 14 JIT-SDP change-level metrics plus stream-control information such as `project_no` and `commit_type`.

The processed stream semantics include delayed label availability. The notebook therefore distinguishes target-project test events from training/label-availability events and excludes cross-project training events from the within-project evaluation.

Each of the four additional raw processed streams contained 32 exact duplicate rows. The study removed these duplicates consistently before construction of the within-project chronological evaluation sets.

## Do not fabricate dataset provenance

If a source dataset is unavailable, do not replace it with a similarly named dataset or a newly downloaded version without documenting the change. The reported manuscript results correspond to the verified experimental inputs and preprocessing protocol used in this repository.

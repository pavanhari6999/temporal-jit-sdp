# Temporal Robustness and Lightweight Adaptation for Just-In-Time Software Defect Prediction

Replication code and experimental workflow for the manuscript:

**Temporal Robustness and Lightweight Adaptation for Just-In-Time Software Defect Prediction**

## Contents

- `code/Adaptive_JIT_SDP_Research_Stage8C_BORB_ready.ipynb` — main research notebook.
- `docs/REPRODUCTION.md` — reproduction instructions.
- `results/README.md` — description of expected generated result files.

## Reproduction

The notebook is designed for Google Colab / Python 3.

The experiments use chronological evaluation. Do **not** replace the chronological protocol with a random train/test split.

The notebook includes:

1. Dataset inspection and validation
2. Chronological historical/future splitting
3. RFE feature selection
4. Random Forest configuration and evaluation
5. Temporal T1–T4 evaluation
6. Cumulative retraining
7. Sliding-window retraining
8. Adaptive threshold sensitivity
9. Bootstrap confidence intervals
10. PSI distribution-shift analysis
11. Class-imbalance sensitivity
12. Random Forest vs XGBoost temporal sensitivity
13. Statistical comparison
14. Result and figure generation

## Data

Raw datasets are not redistributed here unless their licenses permit redistribution.

Use the exact public data sources and preprocessing protocol described in the manuscript and `docs/REPRODUCTION.md`.

## Important scientific note

The repository contains executable research code. Reported manuscript numbers should be reproduced from the exact source data and protocol. Published methods such as BORB, ODaSC, PBSA, DeepJIT, CC2Vec, and JITLine are not claimed to have been exactly reproduced unless an experiment is explicitly identified as executed.

## License

Code: MIT License.

# Reproduction Guide

## 1. Environment

The verified research environment used for the manuscript included:

- Python 3.13.5
- NumPy 2.3.5
- pandas 2.2.3
- scikit-learn 1.8.0
- XGBoost 3.1.3
- SciPy 1.17.0
- Matplotlib 3.10.8

Primary random seed: `42`.

Bootstrap confidence intervals: `2,000` resamples.

## 2. Run

Open:

`code/Adaptive_JIT_SDP_Research_Stage8C_BORB_ready.ipynb`

Run the notebook in Google Colab or an equivalent Python environment.

## 3. Chronological protocol

Historical observations are used for development/training and calibration. Future-test labels must remain unseen until evaluation.

Do not substitute random train/test splitting.

## 4. Outputs

The notebook generates experiment results that can be exported to CSV/JSON and used to reproduce manuscript tables and figures.

## 5. Data integrity

The exact Brackets source used in the verified experiments has SHA-256:

`72d3d69c337a7dd7693363e4c368c459878ef989be6de3a0e37b8aa1081e81fc`

For other project streams, use the exact public source and preprocessing described in the manuscript.

## 6. Interpretation boundary

This repository is a replication package for the experiments reported in the manuscript. It does not claim exact reproduction of every result reported by prior JIT-SDP studies.
